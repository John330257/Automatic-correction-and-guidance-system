/**
 * API索引文件
 * 用于集中导出所有API
 */

export * from './teacher';
export * from './exam';
export * from './ai';
export * from './student';